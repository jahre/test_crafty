-- phpMyAdmin SQL Dump
-- version 4.0.10.6
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3308
-- Время создания: Фев 02 2015 г., 22:36
-- Версия сервера: 5.5.41-log
-- Версия PHP: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `test_base`
--

-- --------------------------------------------------------

--
-- Структура таблицы `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `maintexts`
--

CREATE TABLE IF NOT EXISTS `maintexts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `showhide` enum('show','hide') COLLATE utf8_unicode_ci NOT NULL,
  `lang` enum('ru','eng') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `maintexts`
--

INSERT INTO `maintexts` (`id`, `name`, `body`, `url`, `showhide`, `lang`, `created_at`, `updated_at`) VALUES
(1, 'We are Crafty - Welcom Page', '<section class="billboard">\r\n\r\n<style type="text/css">\r\n.billboard{background: url("media/img/billboard.jpg") no-repeat center center;\r\n\r\nbackground-size: cover;\r\n-webkit-background-size: cover;\r\n-moz-background-size: cover;\r\n-o-background-size: cover;\r\n\r\n}\r\n</style>\r\n\r\n<div class="wrapper">\r\n <div class="caption">\r\n <p>Welcome!</p>\r\n <p>We are Crafty - The best of the best.</p>\r\n </div>\r\n</div>\r\n</section><!--  End Billboard  -->', 'index', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Crafty - Our Story', '<section class="billboard">\r\n\r\n<style type="text/css">\r\n.billboard{background: url("media/img/billboard_story.jpg") no-repeat center center;\r\n\r\nbackground-size: cover;\r\n-webkit-background-size: cover;\r\n-moz-background-size: cover;\r\n-o-background-size: cover;\r\n\r\n}\r\n</style>\r\n\r\n<div class="wrapper">\r\n <div class="caption">\r\n <div class="ourstory_p">\r\n  <p>Our Story</p><br>\r\n  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.\r\n </div>\r\n </div>\r\n</div>\r\n</section><!--  End Billboard  -->', 'ourstory', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Crafty - Our Prices', '<section class="billboard">\r\n\r\n<style type="text/css">\r\n.billboard{background: url("media/img/billboard_price.jpg") no-repeat center center;\r\n\r\nbackground-size: cover;\r\n-webkit-background-size: cover;\r\n-moz-background-size: cover;\r\n-o-background-size: cover;\r\n\r\n}\r\n</style>\r\n\r\n<div class="wrapper">\r\n <div class="caption">\r\n <div class="ourstory_p">\r\n  <p>Our Prices</p><br>\r\n <table>\r\n<tr>\r\n<td><b>Position:<b></td>\r\n<td>0.00$</td>\r\n</tr>\r\n<tr>\r\n<td><b>Position:<b></td>\r\n<td>0.00$</td>\r\n</tr>\r\n<tr>\r\n<td><b>Position:<b></td>\r\n<td>0.00$</td>\r\n</tr>\r\n<tr>\r\n<td><b>Position:<b></td>\r\n<td>0.00$</td>\r\n</tr>\r\n</table>\r\n </div>\r\n </div>\r\n</div>\r\n</section><!--  End Billboard  -->', 'price', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Crafty - Get in Touch', '<section class="billboard">\r\n\r\n<style type="text/css">\r\n.billboard{background: url("media/img/billboard_contact.jpg") no-repeat center center;\r\n\r\nbackground-size: cover;\r\n-webkit-background-size: cover;\r\n-moz-background-size: cover;\r\n-o-background-size: cover;\r\n\r\n}\r\n.billboard .caption .ourstory_p{\r\nbackground: rgba(255, 255, 255, 0.9);\r\n}\r\n</style>\r\n\r\n<div class="wrapper">\r\n <div class="caption">\r\n <div class="ourstory_p">\r\n  <p>Contacts</p><br>\r\n<b>220038</b><br>\r\n Country, City<br>\r\nStreet, 24<br>\r\n9.00-20.00\r\n </div>\r\n </div>\r\n</div>\r\n</section><!--  End Billboard  -->', 'contact', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `maintexts1`
--

CREATE TABLE IF NOT EXISTS `maintexts1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `showhide` enum('show','hide') COLLATE utf8_unicode_ci NOT NULL,
  `lang` enum('ru','eng') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `maintexts1`
--

INSERT INTO `maintexts1` (`id`, `name`, `body`, `url`, `showhide`, `lang`, `created_at`, `updated_at`) VALUES
(1, 'welcome', 'aaaa', 'index', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'story', 'bbbb', 'ourstory', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'price', 'cccc', 'price', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'journal', 'dddd', 'journal', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'contact', 'eeee', 'contact', 'show', 'eng', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_01_21_184457_maintexts', 1),
('2015_01_23_174631_users', 2),
('2015_01_26_195047_items', 3),
('2015_01_30_181523_products', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` text COLLATE utf8_unicode_ci NOT NULL,
  `quantity` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `img` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `showhide` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `quantity`, `description`, `img`, `created_at`, `updated_at`, `showhide`) VALUES
(1, '111', '111', '111', '111', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(2, 'apple', '20', '100', 'red', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(3, 'pear', '30', '100', 'yellow', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(4, 'egg', '50', '1231', 'white', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(5, 'box', '1000', '5', '', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0),
(32, 'mouse', '', '', '', '15_02_02_07_34_25.jpg', '2015-02-02 05:34:25', '2015-02-02 05:34:25', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `username`, `isAdmin`, `isActive`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, 'mail1', '$2y$10$VwDUxHM2LCSTlOzQKTSNTeAeCKdNv3ogJTsnfS7IGP8JFN3kU4U8a', 'user1', 0, 0, 'e10HbppTG74VXrn4xSbWhikJlzFvhZZh8eoglxzC70DW39iSKcfYq5UqQgn5', '2015-01-23 04:47:41', '2015-01-28 17:29:44'),
(7, 'user40', '$2y$10$CP1uiBFto9kumh.fn8e4/.227vm5SilhxTeS6yY3oiC0iTYnP7Gm2', 'user40', 0, 0, NULL, '2015-01-23 05:16:15', '0000-00-00 00:00:00'),
(9, 'email2', '$2y$10$HXUAOLLsu49eJngQmGkEcuzwykwFeKycNNFtx29OJxZJu0wVtePpG', 'test_user2', 0, 0, NULL, '2015-01-23 05:36:48', '0000-00-00 00:00:00'),
(11, 'admin@tt.tt', '$2y$10$56SIun4MocHpPsmj9ni1MuncpWa61rrQO/riO8tJ6apMTB24IUsUy', 'admin', 1, 0, '2HeyTmu1wlFvrbW42nCyS3OxQiS7mNJsga61yjlnBbQRQyMP0Nu8RUJdVOXP', '2015-01-28 03:23:47', '2015-01-28 17:25:02');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
